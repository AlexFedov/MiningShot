# Welcome to the Koii app!

**Important Note:** This application is password protected for added security.

########## Installation Instructions

  Open the program inside this archive by entering the password “koii”.


## Security information

We take the security of our users very seriously. This application has been tested and is safe to use, it contains no viruses or malware.  Please make sure you download this app from a trusted source to ensure it is a verified copy.

## Support and additional information

For more information about the application or in case of any issues, please visit our official website:

https://www.koii.run

Thank you for choosing our app! We appreciate your trust and hope you enjoy using it.

---
This README is a digitally signed document guaranteeing its authenticity._
